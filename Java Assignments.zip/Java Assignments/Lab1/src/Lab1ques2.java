import java.util.Scanner;


public class Lab1ques2 {
	int calculateDifference(int n){
		int m;
		int sq=0;
		int sum=0;
		for(int i=1;i<=n;i++){
			m=i*i;
			sq=sq+m;
			sum+=i;
		}
		int k=sum*sum;
		int d=k-sq;
		return d;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the value of n");
		n=s.nextInt();
		Lab1ques2 l=new Lab1ques2();
		int sum=l.calculateDifference(n);
		System.out.println("The difference :"+sum);
		s.close();

	}

}
