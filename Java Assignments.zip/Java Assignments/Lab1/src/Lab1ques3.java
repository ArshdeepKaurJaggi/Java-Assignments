import java.util.Scanner;


public class Lab1ques3 {
	
	boolean checkNumber(int n){
		int r,l=10;
		while(n!=0){
			r=n%10;
			if(r>l){return false;}
			l=r;
			n=n/10;
		}
		return true;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number");
		n=s.nextInt();
		Lab1ques3 l=new Lab1ques3();
		boolean b=l.checkNumber(n);
		if(b==true){
			System.out.println("The number is increasing number");
		}else{
			System.out.println("The number is not an increasing number");
		}
		s.close();
	}

}
