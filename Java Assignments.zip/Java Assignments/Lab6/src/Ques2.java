import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;
public class Ques2 {
	
	void writeFile(){
		try{
			FileWriter f=new FileWriter("abc.txt");
			String st="hehehe hehhehe \n jajajja uauuau \n j";
			f.write(st);
			f.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
		System.out.println("File created");
	}
	void readFile() throws IOException{
		BufferedReader b=null;
		FileReader fr=new FileReader("abc.txt");
		try {
		b=new BufferedReader(fr);
		String line=b.readLine();
		int i=1;
		while(line!=null){
			System.out.println(i + " "+line);
			i++;
			line=b.readLine();
		}
	
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Ques2 q=new Ques2();
		q.writeFile();
		q.readFile();

	}

}
