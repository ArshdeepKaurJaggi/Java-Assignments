import java.util.Scanner;
import java.io.*;

public class Ques4 {
	private static String getFileExtension(File file) {
        String fileName = file.getName();
        if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
        return fileName.substring(fileName.lastIndexOf(".")+1);
        else return "";
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name of file");
		String s=sc.next();
		File f=new File(s);
		try {
			if(f.createNewFile()){
				System.out.println("The file is created");
				System.out.println("File Name is " +f.getName());
			}
			else{
				System.out.println("Already exists file");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Is Readable:"+f.canRead());
		System.out.println("IS Writable:"+f.canWrite());
		System.out.println("File Size:"+f.length()+"bytes");
		 System.out.println("File extension is: "+getFileExtension(f));
		}

}
