import java.util.Scanner;


public class Ques7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Eneter the string");
		String s=sc.next();
		if(s.length()>=12){
			String x="";
			int i=s.lastIndexOf('_');
			if(i>0){
				x=s.substring(i);
			}
			else{
				System.out.println("The string does not have _");
			}
			if(x.compareTo("_job")==0){
				System.out.println("valid");
			}else{
				System.out.println("Invalid");
			}
		}else{
			System.out.println("enter larger string");
		}

	}

}
