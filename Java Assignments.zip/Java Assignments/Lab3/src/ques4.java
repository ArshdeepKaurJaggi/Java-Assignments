import java.util.Scanner;


public class ques4 {
	static void getoccurence(String s){
		int MAX_CHAR = 256; 
		int len=s.length();
		int count[]= new int[MAX_CHAR];
		for(int i=0;i<len;i++){
			count[s.charAt(i)]++;
		}
		 char ch[] = new char[s.length()]; 
	        for (int i = 0; i < len; i++) { 
	            ch[i] = s.charAt(i); 
	            int find = 0; 
	            for (int j = 0; j <= i; j++) { 
	  
	                // If any matches found 
	                if (s.charAt(i) == ch[j])  
	                    find++;                 
	            } 
	  
	            if (find == 1)  
	                System.out.println("Number of Occurrence of " + 
	                 s.charAt(i) + " is:" + count[s.charAt(i)]);             
	        } 
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.next();
		getoccurence(s);
	}

}
