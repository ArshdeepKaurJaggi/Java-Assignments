import java.util.Scanner;
import java.util.Arrays; 


public class ques2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int n;
		System.out.println("Enter number of string");
		n=s.nextInt();
		String arr[]=new String[n];
		System.out.println("Enter strings");
		for(int i=0;i<n;i++){
			arr[i]=s.next();
		}
		Arrays.sort(arr);
		for(int i=0;i<n;i++) {
			arr[i]= arr[i].toLowerCase();
		}
		for(int i=0;i<((n/2)+1);i++) {
			arr[i]= arr[i].toUpperCase();
		}
		for(int i=0;i<n;i++) {
			System.out.println(arr[i]);
		}
	}
	

}
