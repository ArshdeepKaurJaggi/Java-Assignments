import java.util.Scanner;


abstract class Item1{
	private int identification_number;
	private String title;
	private int number_of_copies;
	public int getIdentification_number() {
		return identification_number;
	}
	public void setIdentification_number(int identification_number) {
		this.identification_number = identification_number;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getNumber_of_copies() {
		return number_of_copies;
	}
	public void setNumber_of_copies(int number_of_copies) {
		this.number_of_copies = number_of_copies;
	}	
}
abstract class WrittenItem extends Item1{
	private String author;

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
	
}
public class ques2 extends WrittenItem{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a,b;
		String c,d;
		System.out.println("Enter the identification number:");
		a=sc.nextInt();
		System.out.println("Enter the number of copies:");
		b=sc.nextInt();
		System.out.println("Enter title");
		c=sc.next();
		System.out.println("Enter the author name");
		d=sc.next();
		WrittenItem obj=new ques2();
		obj.setIdentification_number(a);
		obj.setAuthor(d);
		obj.setNumber_of_copies(b);
		obj.setTitle(c);
		System.out.println("The details are as follows");
		System.out.println("Identification Number:"+obj.getIdentification_number());
		System.out.println("Title:"+obj.getTitle());
		System.out.println("Author:"+obj.getAuthor());
		System.out.println("Number of copies"+obj.getNumber_of_copies());

	}

}
